<div class="calculator-tipar-offset">

<label for="title"><?php _e('Introdu titlul', 'calculator-tipar') ?></label>
<input type="text" id="title" name="title" value="<?php echo $title ?>" />

<label for="currency"><?php _e('Moneda', 'calculator-tipar') ?></label>
<input type="text" id="currency" name="currency" value="<?php echo $currency ?>" />

<label for="papersheet_square"><?php _e('Coala offset de la producator (in mp)', 'calculator-tipar') ?></label>
<input type="text" id="papersheet_square" name="papersheet_square" value="<?php echo $papersheet_square ?>" />

<label for="papersheet_square_cutted_on_number"><?php _e('Divizor coala offset in coli de tiparit', 'calculator-tipar') ?></label>
<input type="text" id="papersheet_square_cutted_on_number" name="papersheet_square_cutted_on_number" value="<?php echo $papersheet_square_cutted_on_number ?>" />

<label for="maximum_print_area"><?php _e('Dimensiuni maxime pe care se poate tipari', 'calculator-tipar') ?></label>
<input type="text" id="maximum_print_area" name="maximum_print_area" value="<?php echo $maximum_print_area ?>" />

<label for="papersheet_starting"><?php _e('Prisoase coli de tiparit', 'calculator-tipar') ?></label>
<input type="text" id="papersheet_starting" name="papersheet_starting" value="<?php echo $papersheet_starting ?>" />

<label for="papersheet_maxim_formats"><?php _e('Factor granular', 'calculator-tipar') ?></label>
<input type="text" id="papersheet_maxim_formats" name="papersheet_maxim_formats" value="<?php echo $papersheet_maxim_formats ?>" />

<label for="velocity"><?php _e('Viteza tiparit coli / ora', 'calculator-tipar') ?></label>
<input type="text" id="velocity" name="velocity" value="<?php echo $velocity ?>" />

<label for="printing_hour_price"><?php _e('Cost ora de tiparire', 'calculator-tipar') ?></label>
<input type="text" id="printing_hour_price" name="printing_hour_price" value="<?php echo $printing_hour_price ?>" />

<label for="plate_price"><?php _e('Cost placa tipar', 'calculator-tipar') ?></label>
<input type="text" id="plate_price" name="plate_price" value="<?php echo $plate_price ?>" />

<label for="vat"><?php _e('TVA %', 'calculator-tipar') ?></label>
<input type="text" id="vat" name="vat" value="<?php echo $vat ?>" />

<label for="vat_acronym"><?php _e('Acronim TVA', 'calculator-tipar') ?></label>
<input type="text" id="vat_acronym" name="vat_acronym" value="<?php echo $vat_acronym ?>" />

</div>